package com.jfsd.sdp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jfsd.sdp.model.Items;
import com.jfsd.sdp.model.Order;
import com.jfsd.sdp.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	private OrderRepository repository;

	@Override
	public List<Order> viewAllOrders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> viewOrdersInProfile(int id) {
		return repository.viewOrdersById(id);
	}

	@Override
	public String addOrder(Order o) {
		repository.save(o);
		return "Placed Order Successfully !";
	}

	@Override
	public void deleteOrder(int id) {
		Optional<Order> obj=repository.findById(id);
		Order o=null;
		if(obj.isPresent())
		{
			o=obj.get();
		}
		repository.delete(o);
	}

	@Override
	public long count() {
		return repository.count();
	}

}
