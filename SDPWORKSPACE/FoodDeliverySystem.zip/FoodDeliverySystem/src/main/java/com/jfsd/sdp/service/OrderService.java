package com.jfsd.sdp.service;

import java.util.List;

import com.jfsd.sdp.model.Order;

public interface OrderService {
	
	public List<Order> viewAllOrders();
	public List<Order> viewOrdersInProfile(int id);
	public String addOrder(Order o);
	public void deleteOrder(int id);
	public long count();
}
